---
layout: section
title: speeches
permalink: /speeches
---
{% include sections/last_post.html last_post=site.speeches.last%}
{% include sections/items_except_last.html items=site.speeches%}
